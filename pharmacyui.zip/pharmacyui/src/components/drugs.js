/*import React from 'react'

const Drugs = ({ drugs }) => {
  return (
    <div>
      <center><h1>Contact List</h1></center>
      {drugs.map((drug) => (
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">{drug.name}</h5>
            <h6 class="card-subtitle mb-2 text-muted">{drug.rolno}</h6>
            
          </div>
        </div>
      ))}
    </div>
  )
};

    export default Drugs*/