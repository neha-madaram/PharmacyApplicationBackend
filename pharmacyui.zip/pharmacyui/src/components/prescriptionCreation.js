import React from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import './components.css';

import Card from 'react-bootstrap/card'

// const prescription_creation = () => {
//     return(
//         <div>
//             This is prescription prescription_creation
//         </div>

//     );

// }
// export default prescription_creation;
class prescriptionCreation extends React.Component{

    state ={
        PrescriptionRequest:[],
        Loading: false
    }

    componentDidMount(){
        fetch('http://localhost:8080/prescriptionRequest/?patientId=333&prescriberId=123&comments=abc&priority=high')
        .then(result=>result.json())
        .then((data)=> {
            this.setState({PrescriptionRequest:data, Loading:false})
        })

    }
   
       render (){
        const { Loading, PrescriptionRequest } = this.state;

         return ( 
        <div>
       <div class="extraSpacing">
           &nbsp;
       </div>
    
       <div class="extraSpacing">
           &nbsp;
       </div>
       <div class="extraSpacing">
           &nbsp;
       </div>
       

        <form class="w-25 mx-auto bg-white p-5">
            <div>
                <h4>Prescription Request Form</h4>
            </div>
  <div class="form-group">
    <label for="PrescriberId">Prescriber ID</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Prescriber ID"/>
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Priority</label>
  <select class="custom-select" id="inputGroupSelect01">
    <option selected>Choose Priority</option>
    <option value="1">High</option>
    <option value="2">Medium</option>
    <option value="3">Low</option>
  </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Enter Comments to Prescriber</label>
    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Comments.."/>
  </div>
  <div class="text-center">
            <button type="button" class="btn btn-primary">Submit</button>
</div>
</form>
</div>
    
    );
       }
}
export default prescriptionCreation;
//     state = {
//         drugs: [],
//         Loading: true
//     };

    

//     async componentDidMount() {

//         fetch('http://localhost:8080/getPD')
//     .then(res => res.json())
//     .then((data) => {
//       this.setState({ drugs: data });
//       console.log(this.state.drugs)
//     })
//     .catch(console.log)
// }
    

//     render() {
//         const { Loading, drugs } = this.state;
//     return(
       
//     <div>
//        <div class="extraSpacing">
//            &nbsp;
//        </div>
    
//        <div class="extraSpacing">
//            &nbsp;
//        </div>
//        <section id="services" class="bg-light text-black">
//             <div class="container p-5">
//                     <div class="row">
//                         <div class="mx-auto">
//                             <h4>Create a request for prescription today!</h4>
//                         </div>
//                         </div>
//                             <div class="text-center">
//                                 <Link to='./prescriptionCreation'>
//                             <Button variant="primary">Create </Button>{' '}
//                             </Link>
//                     </div>
//              </div>
//      </section>

//      <section id="services" class="bg-light mt-5 text-dark">
//     <div class="container">
//         <div class="row">
//             <div class="mx-auto p-5">
//                 {drugs.map((items) => (
//                     <div>
//                         <div class="row border">
//                             <h5 class="col-6">{items.patientId}</h5>
//                             <h5 class="col-6">{items.rxId}</h5>
//                         </div>  
//                     </div>    
//                 ))}    
//             </div>    
//         </div>   
//         </div>
//      </section>
//      </div>
//      )};
//     }
    
    
   
     
