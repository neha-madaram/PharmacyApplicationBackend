import React from 'react'

const PayABill = () => {
    return (
       <div>thsi is pay a bill page</div>


    );
}

export default PayABill;