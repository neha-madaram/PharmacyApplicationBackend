import React from 'react'
const LocatePharmacy = ()=> {

    return(
        <div>
            This is locate Pharmacy
        </div>
    );
    
}
export default LocatePharmacy