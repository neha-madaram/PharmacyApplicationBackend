import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/card'
const RecentOrder = ()=> {
    return (
        <div>
       
    </div>

    );
    
}
export default RecentOrder