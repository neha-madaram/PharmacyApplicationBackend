import React from 'react'
import './components.css'

const Home = () => {
    const stylePrescriptions = {backgroundColor : 'red'};
    const styleOrders = {backgroundColor : 'blue'};
    const styleAccount = {backgroundColor : 'yellow'};
    return (
        
        <div>
       <div class="extraSpacing">
           &nbsp;
       </div>
       <div class="extraSpacing">
           &nbsp;
       </div>
       <div class="extraSpacing">
           &nbsp;
       </div>
       <div class="extraSpacing">
           &nbsp;
       </div>
       <div class="text">
       Welcome to Pharmacy! This is the place where you can not just order your prescriptions <br/>
       but also get help from our highly specialized doctors.
       </div>
       
       </div>
  


    );
}

export default Home;