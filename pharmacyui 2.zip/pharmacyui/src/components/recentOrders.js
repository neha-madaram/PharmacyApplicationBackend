import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
const RecentOrder = ()=> {
    return (
        <div>
       
    </div>

    );
    
}
export default RecentOrder