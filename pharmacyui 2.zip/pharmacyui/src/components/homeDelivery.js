import React from 'react'

const HomeDelivery= ()=>
{
    return(
<div>
    this is home delivery page
</div>
    );
}
export default HomeDelivery;